package com.example.Bibloteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiblotecaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BiblotecaApplication.class, args);
	}

}
